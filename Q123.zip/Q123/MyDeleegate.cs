﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q123
{
    public delegate void MyDelegate();
    public delegate void Greet(string str);
}
