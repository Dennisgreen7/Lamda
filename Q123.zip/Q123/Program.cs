﻿using System;

namespace Q123
{
    class Program
    {
        static void Main(string[] args)
        {
            MyDelegate mydelegate1 = () => { Console.WriteLine("Shalom"); };
            mydelegate1();
            MyDelegate mydelegate2 = () => { Console.WriteLine("Another function with same delegate"); };
            mydelegate2();
            Greet greet1 = Name => { Console.WriteLine("Shalom " + Name); };
            greet1("Dennis");
            Greet greet2 = Name => { Console.WriteLine("Welcome " + Name); };
            greet2("Cristiano");
            Console.ReadLine();
        }
    }
}
