﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesHM
{
    class Program
    {
        //1.
        public static void Shalom() 
        {
            Console.WriteLine("Shalom");
        }
        public static void Print2()
        {
            Console.WriteLine("Another function called with same delegate ");
        }
        //2.
        public static void ShalomName(string name)
        {
            Console.WriteLine("Shalom "+name);
        }
        public static void WelcomeName(string name)
        {
            Console.WriteLine("Welcome " + name);
        }
        static void Main(string[] args)
        {
            //1.
            MyFirstDelegate ShalomDelegate = Shalom;
            MyFirstDelegate ShalomDelegate1 = delegate { Console.WriteLine("Shalom 1"); };
            MyFirstDelegate PrintDelegate = Print2;
            ShalomDelegate();
            ShalomDelegate1();
            PrintDelegate();
            //2.
            Greet HelloDelegate = ShalomName;
            Greet HelloDelegate1 = delegate(string name) { Console.WriteLine("Welcome " + name); };
            Greet WelcomeDelegate = WelcomeName;
            HelloDelegate("Dennis");
            HelloDelegate1("Dennis1");
            WelcomeDelegate("Dennis");
            //3.
            //לא יעבוד מכיוון שהדלאגייט של גרייט מקבל פונקציה שמקבלות פרמטר של סטרינג והפונקציה פרינט2 
            //היא פונקציה ללא פרמטרים לכן זה לא יעבוד 
            Console.ReadLine();
        }
    }
}
