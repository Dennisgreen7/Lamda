﻿delegate void MyFirstDelegate();
delegate void Greet(string name);