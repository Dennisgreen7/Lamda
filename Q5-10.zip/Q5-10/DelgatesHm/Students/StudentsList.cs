﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    public class StudentsList
    {
        public List<Student> studentsList { get; set; } = new List<Student>();

        public void Add(Student student)
        {
            studentsList.Add(student);
        }

        public void Remove(Student student)
        {
            studentsList.Remove(student);
        }
        public List<Student> Filter(FilterDelegate filterDelegateInstance, string str)
        {
            var list = new List<Student>();
            foreach (var item in studentsList)
            {
                if (filterDelegateInstance(item, str))
                    list.Add(item);
            }
            return list;
        }
        public bool Contains(CheckDelegate checdelegate)
        {
            foreach (var item in studentsList)
            {
                if (checdelegate(item))
                    return true;
            }
            return false;
        }
        public string  Sum(SumDelegate sumsdelegate)
        {
            int sum = 0;
            foreach (var student in studentsList)
            {
                sum += sumsdelegate(student);
            }
            return sum.ToString();
        }
        public string Avrage(AverageDelegate averagedelegate)
        {
            decimal sum = 0;
            decimal average;
            foreach (var student in studentsList)
            {
                sum += averagedelegate(student);
            }
            average = sum / studentsList.Count;
            return average.ToString();
        }
    }
}
