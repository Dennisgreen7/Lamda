﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    public class Student
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal Age { get; set; }
        public decimal Grade { get; set; }
        public int Paid { get; set; } = 0;
        public int NeedToPay { get; set; }

        public Student(string id, string firstName, string lastName, decimal age, decimal grade, int paid)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Age = age;
            Grade = grade;
            Paid = paid;
            NeedToPay = 200-paid;
        }
    }
}
